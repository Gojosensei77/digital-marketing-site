import React from 'react';

function Services() {
  return (
    <div style={{ padding: '2rem' }}>
      <h2>Our Services</h2>
      <ul>
        <li>SEO Optimization</li>
        <li>Social Media Management</li>
        <li>Content Marketing</li>
        <li>PPC Campaigns</li>
        <li>Email Marketing</li>
      </ul>
    </div>
  );
}

export default Services;