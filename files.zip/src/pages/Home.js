import React from 'react';
import styled from 'styled-components';

const Hero = styled.section`
  background: linear-gradient(120deg, #09f, #f0f6ff);
  color: #222;
  padding: 5rem 2rem;
  text-align: center;
`;

const Title = styled.h1`
  font-size: 2.5rem;
  margin-bottom: 1rem;
`;

const Subtitle = styled.p`
  font-size: 1.2rem;
`;

function Home() {
  return (
    <Hero>
      <Title>Grow Your Business with Us!</Title>
      <Subtitle>
        We drive results through innovative digital marketing strategies.<br />
        Get started with your online growth today.
      </Subtitle>
    </Hero>
  );
}

export default Home;