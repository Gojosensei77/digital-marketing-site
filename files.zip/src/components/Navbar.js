import React from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components';

const Nav = styled.nav`
  background: #222;
  padding: 1rem 2rem;
  display: flex;
  justify-content: space-between;
`;

const NavLinks = styled.div`
  display: flex;
  gap: 1.5rem;
`;

const StyledLink = styled(Link)`
  color: #fff;
  text-decoration: none;
  font-weight: 500;
  &:hover {
    color: #09f;
  }
`;

const Logo = styled.div`
  color: #09f;
  font-size: 1.4rem;
  font-weight: bold;
`;

function Navbar() {
  return (
    <Nav>
      <Logo>DigitalMarketer</Logo>
      <NavLinks>
        <StyledLink to="/">Home</StyledLink>
        <StyledLink to="/about">About</StyledLink>
        <StyledLink to="/services">Services</StyledLink>
        <StyledLink to="/contact">Contact</StyledLink>
      </NavLinks>
    </Nav>
  );
}

export default Navbar;